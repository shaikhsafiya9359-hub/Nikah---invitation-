const reel=document.getElementById("reel");
const envScreen=document.getElementById("envelopeScreen");
const seal=document.getElementById("openSeal");
const popScreen=document.getElementById("popScreen");
const music=document.getElementById("music");
const musicBtn=document.getElementById("musicBtn");

seal.addEventListener("click",()=>{
  if(navigator.vibrate) navigator.vibrate([40,30,80]);
  envScreen.classList.add("open");
  music.volume=.22;
  music.play().catch(()=>{});
  setTimeout(()=>{
    popScreen.classList.add("ready");
    popScreen.scrollIntoView({behavior:"smooth",block:"start"});
  },700);
});

musicBtn.addEventListener("click",()=>{
  if(music.paused){music.play().catch(()=>{});musicBtn.textContent="♫";}
  else{music.pause();musicBtn.textContent="🔇";}
});

/* countdown: 09 Nov 2026 7:00 PM IST */
const target=new Date("2026-11-09T19:00:00+05:30").getTime();
function tick(){
  let d=Math.max(0,target-Date.now());
  const days=Math.floor(d/86400000);d%=86400000;
  const hours=Math.floor(d/3600000);d%=3600000;
  const minutes=Math.floor(d/60000);d%=60000;
  const seconds=Math.floor(d/1000);
  document.getElementById("days").textContent=String(days).padStart(2,"0");
  document.getElementById("hours").textContent=String(hours).padStart(2,"0");
  document.getElementById("minutes").textContent=String(minutes).padStart(2,"0");
  document.getElementById("seconds").textContent=String(seconds).padStart(2,"0");
}
tick();setInterval(tick,1000);

/* heart scratch canvas */
const canvas=document.getElementById("scratchCanvas");
const ctx=canvas.getContext("2d");
let drawing=false,last=null;
function heartPath(c,w,h){
  const p=new Path2D();
  const x=0,y=0;
  p.moveTo(w/2,h*.86);
  p.bezierCurveTo(w*.18,h*.64,w*.03,h*.47,w*.10,h*.27);
  p.bezierCurveTo(w*.17,h*.06,w*.41,h*.03,w/2,h*.25);
  p.bezierCurveTo(w*.59,h*.03,w*.83,h*.06,w*.90,h*.27);
  p.bezierCurveTo(w*.97,h*.47,w*.82,h*.64,w/2,h*.86);
  p.closePath();
  return p;
}
function sizeCanvas(){
  const r=canvas.getBoundingClientRect(),d=devicePixelRatio||1;
  canvas.width=r.width*d;canvas.height=r.height*d;ctx.setTransform(d,0,0,d,0,0);paint();
}
function paint(){
  const r=canvas.getBoundingClientRect(),w=r.width,h=r.height;
  ctx.clearRect(0,0,w,h);
  ctx.save();ctx.clip(heartPath(ctx,w,h));
  const g=ctx.createLinearGradient(0,0,w,h);
  g.addColorStop(0,"#e8cf8b");g.addColorStop(.5,"#b77e2f");g.addColorStop(1,"#f4dda5");
  ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
  for(let i=0;i<320;i++){ctx.beginPath();ctx.arc(Math.random()*w,Math.random()*h,Math.random()*1.8+.3,0,Math.PI*2);ctx.fillStyle="rgba(255,245,205,.65)";ctx.fill()}
  ctx.restore();
}
function erase(e){
  if(!drawing)return;e.preventDefault();
  const r=canvas.getBoundingClientRect(),p=e.touches?e.touches[0]:e;
  const x=p.clientX-r.left,y=p.clientY-r.top;
  ctx.save();ctx.globalCompositeOperation="destination-out";ctx.lineWidth=45;ctx.lineCap="round";ctx.beginPath();
  if(last)ctx.moveTo(last.x,last.y);ctx.lineTo(x,y);ctx.stroke();ctx.restore();last={x,y};
}
canvas.addEventListener("pointerdown",e=>{drawing=true;last=null;erase(e)});
canvas.addEventListener("pointermove",erase);
window.addEventListener("pointerup",()=>{drawing=false;last=null});
canvas.addEventListener("touchstart",e=>{drawing=true;last=null;erase(e)},{passive:false});
canvas.addEventListener("touchmove",erase,{passive:false});
canvas.addEventListener("touchend",()=>{drawing=false;last=null});
window.addEventListener("resize",sizeCanvas);sizeCanvas();

/* fireworks after enough scratch: auto fire when 45% canvas becomes transparent */
function scratchPercent(){
  const r=canvas.getBoundingClientRect(), sx=Math.max(1,Math.floor(canvas.width/100)), sy=Math.max(1,Math.floor(canvas.height/100));
  let total=0,clear=0;
  const data=ctx.getImageData(0,0,canvas.width,canvas.height).data;
  for(let y=0;y<canvas.height;y+=sy*2)for(let x=0;x<canvas.width;x+=sx*2){total++;if(data[(y*canvas.width+x)*4+3]<25)clear++}
  return total?clear/total:0;
}
let fired=false;
canvas.addEventListener("pointermove",()=>{if(!fired&&scratchPercent()>.45){fired=true;fireworks()}});
canvas.addEventListener("touchmove",()=>{if(!fired&&scratchPercent()>.45){fired=true;fireworks() }},{passive:true});
function fireworks(){
  const wrap=document.getElementById("fireworks");wrap.style.position="absolute";wrap.style.inset="0";wrap.style.pointerEvents="none";
  for(let burst=0;burst<7;burst++)setTimeout(()=>burstFx(wrap),burst*260);
}
function burstFx(wrap){
  const cx=20+Math.random()*60,cy=15+Math.random()*50;
  for(let i=0;i<34;i++){
    const p=document.createElement("i");
    p.style.position="absolute";p.style.left=cx+"%";p.style.top=cy+"%";p.style.width="5px";p.style.height="5px";p.style.borderRadius="50%";p.style.background=i%2?"#f3d58f":"#fff4c8";p.style.boxShadow="0 0 10px #f3d58f";p.style.transition="1.1s";
    wrap.appendChild(p);
    const a=Math.PI*2*i/34,dist=55+Math.random()*100;
    requestAnimationFrame(()=>{p.style.transform=`translate(${Math.cos(a)*dist}px,${Math.sin(a)*dist}px)`;p.style.opacity="0"});
    setTimeout(()=>p.remove(),1200);
  }
}
